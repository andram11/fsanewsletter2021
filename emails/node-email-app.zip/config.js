module.exports = {
    USER: 'andra.mertilos@intys.eu',
    PASS: 'rtyFGH12072021?_'
}