module.exports = {
    USER: 'andra.mertilos@intys.eu',
    PASS: 'GHKXCV17?a'
}